import BackMan as agent
import gameMasterNoPrint

for i in range(5000):
        gameMasterNoPrint.run(agent, agent, 3)
