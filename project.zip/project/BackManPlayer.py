'''BackMan.py
This Backgammon player simply asks the user to decide how
to move.  It can be used either to test another agent in
a competition, or to test the game master itself.

'''

from backgState import *

def move(state, die1, die2):
  w = state.whose_move
  print("I'm playing "+get_color(w))
  print("Tell me which checkers to move, with point numbers, e.g., 19,7")
  print("Use 0 to move from the bar.")
  print("If you want your first (or only) checker to move according")
  print("to the 2nd die, add a 3rd argument R: e.g., 19,7,R to reverse the dice.")
  print("For only 1 checker to move with both dice, give as 2nd argument the point number")
  print("where the checker will be after the move is half done.")
  ans = input("or enter Q to quit: ")
  possible_moves = moves_by_2(state, die1, die2)
  possible_moves['p'] = bgstate(state)
  possible_moves['q'] = bgstate(state)
  while (ans not in possible_moves):
    print("allowed moves: ")
    print(list(possible_moves.keys()))
    ans = input("enter again: ")
  return ans
  #return "Q" # quit

def moves_by_2(state, die1, die2):

    only_die1_moves = []
    only_die2_moves = []
    die1_die2_moves = []
    die2_die1_moves = []

    # find moves using only one die
    only_die1_moves = moves(state, die1)
    only_die2_moves = moves(state, die2)

    # find states after using one die
    only_die1_states = {}
    only_die2_states = {}
    for location in only_die1_moves:
        only_die1_states[location] = find_next_state(state, location, die1)
    for location in only_die2_moves:
        only_die2_states[location] = find_next_state(state, location, die2)

    # find moves by using die1, then die2
    for m in only_die1_states:
        second_moves = moves(only_die1_states[m], die2)
        for m2 in second_moves:
            die1_die2_moves += [(m, m2)]

    # find mvoes by using die2, then die1
    for m in only_die2_states:
        second_moves = moves(only_die2_states[m], die1)
        for m2 in second_moves:
            die2_die1_moves += [(m, m2)]

    result = {}
    for n in only_die1_states :
        result[str(n) + ',p'] = only_die1_states[n]
    for n in only_die2_states :
        result[str(n) + ',p,R'] = only_die2_states[n]
    for n in die1_die2_moves :
        result[str(n[0]) + ',' + str(n[1])] = find_next_state(only_die1_states[n[0]], n[1], die2)
    for n in die2_die1_moves :
        result[str(n[0]) + ',' + str(n[1]) + ',R'] = find_next_state(only_die2_states[n[0]], n[1], die1)
    return result





# return a list of points to move from
def moves(state, die):
    who = state.whose_move
    moves = []

    # try to move from bar
    if who in state.bar:
        goal = 0
        if who == 0:
            goal = die
        else:
            goal = 25 - die
        if ((1^who) not in state.pointLists[goal-1]) or (len(state.pointLists[goal-1]) == 1):
            return [0]
        else :
            return []

    current = 0
    goal = 0

    # try to move from the borad, but not home quarter
    for i in range(1,25):
        if who == 0:
            current = i
            goal = current + die
        else:
            current = 25 - i
            goal = current - die
        if (who in state.pointLists[current-1]) and (0 < goal < 25):
            if ((1^who) not in state.pointLists[goal-1]) or (len(state.pointLists[goal-1]) == 1):
                moves = moves + [current]

    # try to move off the board
    if all_in_home(state):
        for i in range(19,25):
            if who == 0:
                current = i
                goal = current + die
            else:
                current = 25 - i
                goal = current - die
            if (who in state.pointLists[current-1]):
                if goal == 25 or goal == 0:       ############## add the case, for farest checker, when die is only one greater than necessary
                    moves = moves + [current]
    return moves

# whether the current player's checkers are all in the home quarter
def all_in_home(state):
    who = state.whose_move
    current = 0
    goal = 0

    for i in range(1,19):
        if who == 0:
            current = i
        else:
            current = 25 - i
        if (who in state.pointLists[current-1]):
            return False
    return True

# move the checker from location by die steps
def find_next_state(state, location, die):
    result = bgstate(state) # create a new state

    if state.whose_move == 0:
        goal = die
    else:
        goal = 25 - die

    if location == 0 : # if we want to move things from the bar
        result.bar.remove(result.whose_move) # remove the corresponding color from the bar
        # if the destination has the opposite color
        if len(result.pointLists[goal - 1]) != 0 and result.pointLists[goal - 1][0] != result.whose_move :
            result.pointLists[goal - 1][0] == result.whose_move
            result.bar.append(flip(result.whose_move))
        else :
            result.pointLists[goal - 1].append(result.whose_move)
    else :
        result.pointLists[location - 1].remove(result.whose_move)
        if result.whose_move == 0 :
            if location + die > 24 :
                result.white_off.append(0)
            elif len(result.pointLists[location - 1 + die]) != 0 and result.pointLists[location - 1 + die][0] == 1:
                result.pointLists[location - 1 + die][0] = 0
                result.bar.append(1)
            else :
                result.pointLists[location - 1 + die].append(0)
        else :
            if location - die < 1 :
                result.red_off.append(1)
            elif len(result.pointLists[location - 1 - die]) != 0 and result.pointLists[location - 1 - die][0] == 0 :
                result.pointLists[location - 1 - die][0] = 1
                result.bar.append(0)
            else :
                result.pointLists[location - 1 - die].append(1)
    return result


def flip(n):
    if n == 1: return 0
    if n == 0: return 1